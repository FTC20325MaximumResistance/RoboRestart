package org.firstinspires.ftc.teamcode.auto;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;

import org.firstinspires.ftc.teamcode.util.Hard_Auto;
import org.firstinspires.ftc.teamcode.util.Hardware;
@SuppressWarnings("unused")
@Autonomous(name = "P2_A1", group = "Auto")
public class P2_A1 extends LinearOpMode {

    Hard_Auto r = new Hard_Auto();

    @Override
    public void runOpMode() throws InterruptedException {

        //This initializes the autonomous
        r.initRobot(this);
        r.initAuto();

        //This waits until we start
        waitForStart();

        r.setDriverMotorMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        r.movedist(Hard_Auto.direction.FORWARD, 0.6, 5);
//        r.waiter(1000);
        while(r.frontRight.getCurrentPosition() != r.frontRight.getTargetPosition() && opModeIsActive()){
            // Do nothing
        }
        r.setToStill();

    }
}