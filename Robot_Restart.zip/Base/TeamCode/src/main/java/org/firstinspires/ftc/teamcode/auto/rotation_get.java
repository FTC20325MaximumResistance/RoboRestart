package org.firstinspires.ftc.teamcode.auto;

import com.qualcomm.hardware.bosch.BNO055IMU;
import com.qualcomm.hardware.bosch.JustLoggingAccelerationIntegrator;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.AxesOrder;
import org.firstinspires.ftc.robotcore.external.navigation.AxesReference;
import org.firstinspires.ftc.robotcore.external.navigation.Orientation;
import org.firstinspires.ftc.teamcode.util.Hardware;

@Autonomous(name = "rotation_get", group = "Auto")
public class rotation_get extends LinearOpMode {

    Hardware r = new Hardware();

    BNO055IMU imu;

    Orientation angles;

    @Override
    public void runOpMode() throws InterruptedException {

        //This initializes the autonomous
        r.initRobot(this);
        r.initAuto();

        BNO055IMU.Parameters parameters = new BNO055IMU.Parameters();
        parameters.angleUnit           = BNO055IMU.AngleUnit.DEGREES;
        parameters.accelUnit           = BNO055IMU.AccelUnit.METERS_PERSEC_PERSEC;
        parameters.calibrationDataFile = "BNO055IMUCalibration.json"; // see the calibration sample opmode
        parameters.loggingEnabled      = true;
        parameters.loggingTag          = "IMU";
        parameters.accelerationIntegrationAlgorithm = new JustLoggingAccelerationIntegrator();

        imu = hardwareMap.get(BNO055IMU.class, "IMU");
        imu.initialize(parameters);

        //This waits until we start
        waitForStart();

        r.setDriverMotorMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        //This is where the fun begins!

        telemetry.addAction(() -> angles = imu.getAngularOrientation(AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES));

        telemetry.addLine()
                .addData("X", "%2.2f", () -> angles.firstAngle)
                .addData("Y", "%2.2f", () -> angles.secondAngle)
                .addData("Z", "%2.2f", () -> angles.thirdAngle);

        while(opModeIsActive()){
            telemetry.update();

        }

    }
}
