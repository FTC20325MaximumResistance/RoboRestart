package org.firstinspires.ftc.teamcode.util;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.DcMotor;

public class Hard_Auto extends Hardware{

    @Override
    public void initAuto(){
        super.initAuto();
    }

    @Override
    public void initRobot(OpMode opMode){
        super.initRobot(opMode);

        // TODO: Home the lift


    }

    /**
     * Move the robot in a specific way
     * @param dir Direction you want to move
     * @param power The power being sent to the motors
     */
    public void move(direction dir, double power){
        switch (dir){
            case FORWARD:
                frontLeft.setPower(power);
                frontRight.setPower(power);
                backLeft.setPower(power);
                backRight.setPower(power);
                break;
            case BACKWARD:
                frontLeft.setPower(-power);
                frontRight.setPower(-power);
                backLeft.setPower(-power);
                backRight.setPower(-power);
                break;
            case LEFT:
                frontLeft.setPower(-power);
                backLeft.setPower(power);
                frontRight.setPower(power);
                backRight.setPower(-power);
                break;
            case RIGHT:
                frontLeft.setPower(power);
                backLeft.setPower(-power);
                frontRight.setPower(-power);
                backRight.setPower(power);
                break;
            case CWISE:
                frontLeft.setPower(power);
                frontRight.setPower(power);
                backLeft.setPower(-power);
                backRight.setPower(-power);
                break;
            case CCWISE:
                frontLeft.setPower(-power);
                frontRight.setPower(-power);
                backLeft.setPower(power);
                backRight.setPower(power);
                break;
        }
    }

    /**
     * Move the robot a specific distance
     * @param dir The distance you want to move
     * @param power The power you want to send to the motors
     * @param distance The distance you want to move in inches
     */
    public void movedist(direction dir, double power, double distance){
        setDriverMotorMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        waiter(500);
        setDriverMotorMode(DcMotor.RunMode.RUN_TO_POSITION);

        double ticks_for_dist = distance/ticks_per_inch;

        switch (dir) {
            case FORWARD:
                frontLeft.setTargetPosition((int) ticks_for_dist);
                frontRight.setTargetPosition((int) ticks_for_dist);
                backLeft.setTargetPosition((int) ticks_for_dist);
                backRight.setTargetPosition((int) ticks_for_dist);
                frontLeft.setPower(power);
                frontRight.setPower(power);
                backLeft.setPower(power);
                backRight.setPower(power);
                break;
            case BACKWARD:
                frontLeft.setTargetPosition((int) -ticks_for_dist);
                frontRight.setTargetPosition((int) -ticks_for_dist);
                backLeft.setTargetPosition((int) -ticks_for_dist);
                backRight.setTargetPosition((int) -ticks_for_dist);
                frontLeft.setPower(-power);
                frontRight.setPower(-power);
                backLeft.setPower(-power);
                backRight.setPower(-power);
                break;
            case LEFT:
                frontLeft.setTargetPosition((int) -ticks_for_dist);
                frontRight.setTargetPosition((int) ticks_for_dist);
                backLeft.setTargetPosition((int)   ticks_for_dist);
                backRight.setTargetPosition((int) -ticks_for_dist);
                frontLeft.setPower(-power);
                backLeft.setPower(power);
                frontRight.setPower(power);
                backRight.setPower(-power);
                break;
            case RIGHT:
                frontLeft.setTargetPosition((int)   ticks_for_dist);
                frontRight.setTargetPosition((int) -ticks_for_dist);
                backLeft.setTargetPosition((int)   -ticks_for_dist);
                backRight.setTargetPosition((int)   ticks_for_dist);
                frontLeft.setPower(power);
                backLeft.setPower(-power);
                frontRight.setPower(-power);
                backRight.setPower(power);
                break;
        }
    }

    public enum direction {
        FORWARD,
        BACKWARD,
        LEFT,
        RIGHT,
        CWISE,
        CCWISE
    }

}
